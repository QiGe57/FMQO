#!/bin/bash
java -Xmx1024m -cp bin:lib/* com.fluidops.fedx.CLI $*
